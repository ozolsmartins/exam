const timer = document.getElementById("timer");
const startButton = document.getElementById("start");
const pauseButton = document.getElementById("pause");
const resetButton = document.getElementById("reset");
const shortBreakButton = document.getElementById("short-break");
const longBreakButton = document.getElementById("long-break");

let workTime = 25;
let shortBreakTime = 5;
let longBreakTime = 15;
let timeLeft = workTime * 60;
let timerInterval;
let timerRunning = false;

function formatTime(timeInSeconds) {
	let minutes = Math.floor(timeInSeconds / 60);
	let seconds = timeInSeconds % 60;
	return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

function updateTimer() {
		timer.textContent = formatTime(timeLeft);
	}
function startTimer() {
	timerRunning = true;
	timerInterval = setInterval(() => {
	timeLeft--;
		if (timeLeft <= 0) {
			resetTimer();

		}
		updateTimer();
	}, 1000);
}

function pauseTimer() {
	timerRunning = false;
	clearInterval(timerInterval);
}

function resetTimer() {
	pauseTimer();
	timeLeft = workTime * 60;
	updateTimer();
}

function setTimer(duration) {
	timeLeft = duration * 60;
    updateTimer();
    resetButton.disabled = false;
    shortBreakButton.disabled = true;
    longBreakButton.disabled = true;
    startTimer();
}
startButton.addEventListener("click", () => {
	if (!timerRunning) {
		startTimer();
	}
});

pauseButton.addEventListener("click", () => {
    if (timerRunning) {
        pauseTimer();
        }
});
resetButton.addEventListener("click", () => {
    if (timerRunning) {
        pauseTimer();
        }
    resetTimer();
        shortBreakButton.disabled = false;
        longBreakButton.disabled = false;
});

shortBreakButton.addEventListener("click", () => {
    if (timerRunning) {
        pauseTimer();
        }
    setTimer(shortBreakTime);
});

longBreakButton.addEventListener("click", () => {
    if (timerRunning) {
        pauseTimer();
        }
    setTimer(longBreakTime);
});


function addTask(){
    var list = document.getElementById("to-do")
    var input = document.getElementById("text").value
    var number = document.getElementById("number").value
    var listElement=document.createElement("li")
    if (number==1){
        listElement.innerHTML=input+" which takes "+number+" long  timer interval"
    }
    else if (number>1){
        listElement.innerHTML=input+" which takes "+number+" long timer intervals"
    }
    list.append(listElement)
    

}
function clearTask(){
    var list = document.getElementById("to-do")
    list.innerHTML=""
}